from django.http import HttpResponse

def home(request):
    return HttpResponse("Chamberlain says Hello!")