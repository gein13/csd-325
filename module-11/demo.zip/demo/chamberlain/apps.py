from django.apps import AppConfig


class ChamberlainConfig(AppConfig):
    name = 'chamberlain'
